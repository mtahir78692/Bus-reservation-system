﻿#include "bus.h"
#include <conio.h>
#include <cstdio>
#include <iostream>
#include <string.h>
#include <cstdlib>
#include <Windows.h>

using namespace std;

void textcolor(int color)
{
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);

	SetConsoleTextAttribute(handle, color);

	return;
}

int main()

{

	system("cls");

	int w;
	bus b;

	while (1)

	{
		textcolor(14);
		cout << endl;
		cout << "           ******************************************" << endl;
		cout << "           *         BUS RESERVATION SYSTEM         *" << endl;
		cout << "           ******************************************" << endl;

		textcolor(10);
		cout << "\n\n\n\n\n";

		cout << "\t\t\t1.Install\n\t\t\t"

			<< "2.Reservation\n\t\t\t"

			<< "3.Show\n\t\t\t"

			<< "4.Buses Available. \n\t\t\t"

			<< "5.Exit";

		textcolor(12);
		cout << "\n\t\t\tEnter your choice:-> ";

		cin >> w;

		switch (w)

		{

		case 1:
			system("cls");
			textcolor(13);
			b.install();
			system("cls");
			break;

		case 2:  
			system("cls");
			textcolor(14);
			b.allotment();
			system("cls");
			break;

		case 3:  
			system("cls");
			textcolor(3);
			b.show();
			break;

		case 4:  
			system("cls");
			textcolor(3);
			b.avail();
			break;

		case 5: 
			system("cls");
			textcolor(3);
			cout << "****EXITING.......";	
			Sleep(700);
			exit(0);
		}

	}

	return 0;

}
