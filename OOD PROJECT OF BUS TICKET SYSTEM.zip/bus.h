#pragma once

class bus
{
	char busn[5];
	char driver[10];
	char arrival[5];
	char depart[5];
	char from[10];
	char to[10];
	char seat[8][4][10];

public:

	bus();
	void install();
	void allotment();
	void empty();
	void show();
	void avail();
	void position(int i);

};