/*USING THE STANDARD LIBRARYS AND HEADER FILES TO MAKE THE SOURCE CODE FOR BUS*/

#include "bus.h"
#include <conio.h>
#include <cstdio>
#include <iostream>
#include <string.h>
#include <cstdlib>
#include <Windows.h>
using namespace std;

/*DECLARING A STATIC VARIABLE*/
static int p = 0;
bus bs[10];

/*MAKING A DEFAULT CONSTRUCTOR OF CLASS BUS*/
bus::bus()
{
	busn[5]='\0';
	driver[10]='\0';
	arrival[5]='\0';
	depart[5]='\0';
	from[10]='\0';
	to[10]='\0';
	seat[8][4][10]='\0';
}
void vline(char ch)

{

	for (int i = 80; i>0; i--)

		cout << ch;

}

/*Fuction to register a new bus which will take the bus no, driver name, 
departure and destination time and City*/
void bus::install()

{
	
	cout << "Enter bus no: ";

	cin >> bs[p].busn;

	cout << "\nEnter Driver's name: ";

	cin >> bs[p].driver;

	cout << "\nArrival time: ";

	cin >> bs[p].arrival;

	cout << "\nDeparture Time: ";

	cin >> bs[p].depart;

	cout << "\nFrom: \t\t\t";

	cin >> bs[p].from;

	cout << "\nTo: \t\t\t";

	cin >> bs[p].to;

	bs[p].empty();

	p++;

}

void bus::allotment()

{
	

	int seat;

	char number[5];

top:

	cout << "Bus no: ";

	cin >> number;

	int n;

	for (n = 0; n <= p; n++)

	{

		if (strcmp(bs[n].busn, number) == 0)

			break;

	}

	while (n <= p)

	{

		cout << "\nSeat Number: ";

		cin >> seat;

		if (seat>32)

		{

			cout << "\nThere are only 32 seats available in this bus.";

		}

		else

		{

			if (strcmp(bs[n].seat[seat / 4][(seat % 4) - 1], "Empty") == 0)

			{

				cout << "Enter passanger's name: ";

				cin >> bs[n].seat[seat / 4][(seat % 4) - 1];

				break;

			}

			else

				cout << "The seat no. is already reserved.\n";

		}

	}

	if (n>p)

	{

		cout << "Enter correct bus no.\n";

		goto top;

	}

}


void bus::empty()

{

	for (int i = 0; i<8; i++)

	{

		for (int j = 0; j<4; j++)

		{

			strcpy_s(bs[p].seat[i][j], "Empty");

		}

	}

}

void bus::show()

{
	
	int n;

	char number[5];

	cout << "Enter bus no: ";

	cin >> number;

	for (n = 0; n <= p; n++)

	{

		if (strcmp(bs[n].busn, number) == 0)

			break;

	}

	while (n <= p)

	{

		vline('*');

		cout << "Bus no: \t" << bs[n].busn

			<< "\nDriver: \t" << bs[n].driver << "\t\tArrival time: \t"

			<< bs[n].arrival << "\tDeparture time:" << bs[n].depart

			<< "\nFrom: \t\t" << bs[n].from << "\t\tTo: \t\t" <<

			bs[n].to << "\n";

		vline('*');

		bs[0].position(n);

		int a = 1;

		for (int i = 0; i<8; i++)

		{

			for (int j = 0; j<4; j++)

			{

				a++;

				if (strcmp(bs[n].seat[i][j], "Empty") != 0)

					cout << "\nThe seat no " << (a - 1) << " is reserved for " << bs[n].seat[i][j] << ".";

			}

		}

		break;

	}

	if (n>p)

		cout << "Enter correct bus no: ";

}

void bus::position(int l)

{

	int s = 0; p = 0;

	for (int i = 0; i<8; i++)

	{

		cout << "\n";

		for (int j = 0; j<4; j++)

		{

			s++;

			if (strcmp(bs[l].seat[i][j], "Empty") == 0)

			{

				cout.width(5);

				cout.fill(' ');

				cout << s << ".";

				cout.width(10);

				cout.fill(' ');

				cout << bs[l].seat[i][j];

				p++;

			}

			else

			{

				cout.width(5);

				cout.fill(' ');

				cout << s << ".";

				cout.width(10);

				cout.fill(' ');

				cout << bs[l].seat[i][j];

			}

		}

	}

	cout << "\n\nThere are " << p << " seats empty in Bus No: " << bs[l].busn;

}

void bus::avail()

{


	for (int n = 0; n<p; n++)

	{

		vline('*');

		cout << "Bus no: \t" << bs[n].busn << "\nDriver: \t" << bs[n].driver

			<< "\t\tArrival time: \t" << bs[n].arrival << "\tDeparture Time: \t"

			<< bs[n].depart << "\nFrom: \t\t" << bs[n].from << "\t\tTo: \t\t\t"

			<< bs[n].to << "\n";

		vline('*');

		vline('_');

	}

}