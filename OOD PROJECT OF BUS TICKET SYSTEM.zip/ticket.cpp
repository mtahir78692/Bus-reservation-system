#include <iostream>
#include <fstream>
#include <string>
#include "ticket.h"
using namespace std;

ticket tick;
ticket::ticket()
{
	resno = 0;
	age = 0;
	tokids = 0;
	towomen = 0;
	tomen = 0;
	tospecial = 0;
	tovvip = 0;
	pname = '\0';
	status = '\0';
}
int ticket::returnresno()
{
	return resno;
}
void ticket::print()
{
	int f = 0;
	system("cls");
	ifstream fn("Ticket1.txt", ios::out); fn.seekg(0);
	if (!fn)
	{
		cout << "ERROR IN THE FILE " << endl;
	}
X:
	cout << "ENTER THE RESERVATION NO ";
	int n;
	cin >> n;
	while (!fn.eof())
	{
		fn.read((char*)&tick, sizeof(tick));
		if (n == resno)
		{
			f = 1;
			system("cls");
			cout << "NAME: ";
			cout << pname;
			cout << "AGE: ";
			cout << age;
			cout << "PRESENT STATUS: ";
			cout << status;
			cout << "RESERVATION NUMBER: ";
			cout << resno;
			cout << "PRESS ANY KEY TO CONTINUE " << endl;
			system("pause");
		}
	}
	if (f == 0)
	{
		system("cls");
		cout << "UNRECOGINIZED RESERVATION NO !!! WANNA RETRY ? (Y / N) ";
		char a;
		cin >> a;
		if (a == 'y' || a == 'Y')
		{
			system("cls");
			goto X;
		}
		else
		{
			cout << "PRESS ANY KEY TO CONTINUE" << endl;
			system("pause");
		}
	}
	fn.close();
}
void ticket::reservation()
{
	system("cls");
	cout << "RESERVATION " << endl;
	cout << "ENTER THE BUS NO: ";
	int bno, f = 0; 
	cin >> bno; 
	ofstream file;
	ifstream fin("bus1.txt", ios::out); fin.seekg(0);
	if (!fin)
	{
		system("cls");
		cout << "ERROR IN THE FILE " << endl;
		system("cls");
		while (!fin.eof())
		{
			fin.read((char*)&tick, sizeof(tick)); int z;
		//	z = tick.rbusno();
			/*if (bno == z)
			{
				f = 1;
				noofkidsseats = tick.rnoofkidsseats();
				noofwomenseats = bs.rnoofwomenseats();
				noofmenseats = bs.rnoofmenseats();
				noofspecialseats = bs.rnoofspecialseats();
				noofvvip = bs.rnoofvvip();
			}*/
		}
		if (f == 1)
		{
			file.open("Ticket1.txt", ios::app);
		S:
			system("cls");
			cout << "NAME:";
			cin >> pname;
			cout << "AGE:";
			cin >> age;
			system("cls");
			cout << "SELECT THE CATEGORY WHICH YOU WISH TO TRAVEL" << endl;
			cout << "1.KIDS CATEGORY" << endl;
			cout << "2.WOMEN CATEGORY" << endl;
			cout << "3.MEN CATEGORY" << endl;
			cout << "4.SPECIAL CATEGORY" << endl;
			cout << "5.SECOND CLASS SLEEPER" << endl;
			cout << "ENTER YOUR CHOICE " << endl;
			int c;
			cin >> c;
			switch (c)
			{
			case 1:
				tokids++;
				resno = rand();
				if ((noofkidsseats - tokids)>0)
				{
					status = "confirmed";
					cout << "STATUS";
					puts(status);
					cout << "RESERVATION NO";
					cout << resno;
					system("pause");
					file.write((char*)&tick, sizeof(tick)); break;

					status = "pending";
					cout << "STATUS";
					puts(status);
					cout << "RESERVATION NO ";
					cout << resno;
					system("pause");
					file.write((char*)&tick, sizeof(tick)); break;
				}

			case 2:
				towomen++;
				resno = rand();
				if ((noofwomenseats - towomen)>0)
				{
					status = "confirmed";
					cout << "STATUS";

					puts(status);
					cout << "RESERVATION NO ";
					cout << resno;
					system("pause");
					file.write((char*)&tick, sizeof(tick)); break;

					status = "pending";
					cout << "STATUS";
					puts(status);
					cout << "RESERVATION NO ";
					cout << resno;
					system("pause");
					file.write((char*)&tick, sizeof(tick)); break;
				}

			case 3:
				tomen++;
				resno = rand();
				if ((noofmenseats - tomen)>0)
				{
					status = "confirmed";
					cout << "STATUS";
					puts(status);
					cout << "RESERVATION NO ";
					cout << resno;
					system("pause");
					file.write((char*)&tick, sizeof(tick)); break;
				}
				else
				{
					status = "pending";
					cout << "STATUS";
					puts(status);
					cout << "RESERVATION NO ";
					cout << resno;
					system("pause");
					file.write((char*)&tick, sizeof(tick)); break;
				}

			case 4:
				tospecial++;
				resno = rand();
				if ((noofspecialseats - tospecial)>0)
				{
					status = "confirmed";
					cout << "STATUS";
					puts(status);
					cout << "RESERVATION NO ";
					cout << resno;
					system("pause");
					file.write((char*)&tick, sizeof(tick)); break;
				}
				else
				{
					status = "pending";
					cout << "STATUS";
					puts(status);
					cout << "RESERVATION NO ";
					cout << resno;
					system("pause");
					file.write((char*)&tick, sizeof(tick)); break;
				}

			case 5:
				tovvip++;
				resno = rand();
				if ((noofvvip - tovvip)>0)
				{
					status = "confirmed";
					cout << "STATUS";
					puts(status);
					cout << "RESERVATION NO ";
					cout << resno;
					system("pause");
					file.write((char*)&tick, sizeof(tick)); break;
				}
				else
				{
					status = "pending";
					cout << "STATUS";
					puts(status);
					cout << "RESERVATION NO ";
					cout << resno;
					system("pause");
					file.write((char*)&tick, sizeof(tick)); break;
				}
			}
			cout << "DO YOU WISH TO CONTINUE BOOKING TICKETS (Y/N) ? ";
			char n;
			cin >> n;
			if (n == 'y' || n == 'Y')
			{
				goto S;
			}
		}
	}
	if (f == 0)
	{
		system("cls");
		cout << "ERROR IN THE BUS NUMBER ENTERED !!!" << endl;
		system("pause");
	}
	file.close();
}
void ticket::cancellation()
{
	system("cls");
	ifstream fin;
	fin.open("Ticket1.txt", ios::out);

	ofstream file;
	file.open("Temp1.txt", ios::app);
	fin.seekg(0);
	cout << "ENTER THE RESERVATION NO: ";
	int r, f = 0;
	cin >> r;
	if (!fin)
	{
		cout << "ERROR IN THE FILE !!!" << endl;
	}
	while (!fin.eof())
	{
		fin.read((char*)&tick, sizeof(tick)); int z;
		z = returnresno();
		if (z != r)
		{
			file.write((char*)&tick, sizeof(tick));
		}
		if (z == r)
		{
			f = 1;
		}
	}
	file.close(); fin.close();
	remove("Ticket1.txt");
	rename("Temp1.txt", "Ticket1.txt");
	if (f == 0)
	{
		cout << "NO SUCH RESERVATION IS MADE !!! PLEASE RETRY	" << endl;
		system("pause");
	}
	else
	{
		cout << "RESERVATION CANCELLED" << endl;
		system("pause");
	}
}