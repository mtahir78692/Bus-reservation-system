#pragma once

class ticket
{
	int resno;
	int age;
	int tokids;
	int towomen;
	int tomen;
	int tospecial;
	int tovvip;
	int noofkidsseats;
	int noofwomenseats;
	int noofmenseats;
	int noofspecialseats;
	int noofvvip;
	char *pname;
	char *status;
public:
	ticket();
	void reservation();
	int returnresno();
	void cancellation();
	void print();
};